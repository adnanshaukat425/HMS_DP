﻿namespace HMS
{
    partial class doctors
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
             System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(doctors));
             System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
             System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
             this.panel1 = new System.Windows.Forms.Panel();
             this.btn_close_window = new System.Windows.Forms.Button();
             this.pictureBox1 = new System.Windows.Forms.PictureBox();
             this.lbl_head = new System.Windows.Forms.Label();
             this.panel2 = new System.Windows.Forms.Panel();
             this.panel_wrapper = new System.Windows.Forms.Panel();
             this.panel3 = new System.Windows.Forms.Panel();
             this.statusStrip1 = new System.Windows.Forms.StatusStrip();
             this.lbl_status = new System.Windows.Forms.ToolStripStatusLabel();
             this.tabControl1 = new System.Windows.Forms.TabControl();
             this.tb_hiredoc = new System.Windows.Forms.TabPage();
             this.pictureBox2 = new System.Windows.Forms.PictureBox();
             this.btn_insert = new System.Windows.Forms.Button();
             this.panel4 = new System.Windows.Forms.Panel();
             this.panel5 = new System.Windows.Forms.Panel();
             this.btn_new_dept = new System.Windows.Forms.Button();
             this.lbl_dep = new System.Windows.Forms.Label();
             this.lb_department = new System.Windows.Forms.ListBox();
             this.panel9 = new System.Windows.Forms.Panel();
             this.txt_add = new System.Windows.Forms.TextBox();
             this.lbl_address = new System.Windows.Forms.Label();
             this.panel8 = new System.Windows.Forms.Panel();
             this.txt_con = new System.Windows.Forms.TextBox();
             this.lbl_contact = new System.Windows.Forms.Label();
             this.panel7 = new System.Windows.Forms.Panel();
             this.lbl_gender = new System.Windows.Forms.Label();
             this.rad_female = new System.Windows.Forms.RadioButton();
             this.rad_male = new System.Windows.Forms.RadioButton();
             this.panel6 = new System.Windows.Forms.Panel();
             this.lbl_name = new System.Windows.Forms.Label();
             this.txt_name = new System.Windows.Forms.TextBox();
             this.tab_viewdoc = new System.Windows.Forms.TabPage();
             this.dgv_doc = new System.Windows.Forms.DataGridView();
             this.txt_search = new System.Windows.Forms.TextBox();
             this.com_search = new System.Windows.Forms.ComboBox();
             this.lbl_search = new System.Windows.Forms.Label();
             this.tab_mandoc = new System.Windows.Forms.TabPage();
             this.pictureBox3 = new System.Windows.Forms.PictureBox();
             this.btn_update = new System.Windows.Forms.Button();
             this.panel10 = new System.Windows.Forms.Panel();
             this.panel11 = new System.Windows.Forms.Panel();
             this.com_dep = new System.Windows.Forms.ComboBox();
             this.label1 = new System.Windows.Forms.Label();
             this.panel12 = new System.Windows.Forms.Panel();
             this.txt_add2 = new System.Windows.Forms.TextBox();
             this.label2 = new System.Windows.Forms.Label();
             this.panel13 = new System.Windows.Forms.Panel();
             this.txt_con2 = new System.Windows.Forms.TextBox();
             this.label3 = new System.Windows.Forms.Label();
             this.panel14 = new System.Windows.Forms.Panel();
             this.label4 = new System.Windows.Forms.Label();
             this.rad_female2 = new System.Windows.Forms.RadioButton();
             this.rad_male2 = new System.Windows.Forms.RadioButton();
             this.panel15 = new System.Windows.Forms.Panel();
             this.txt_name_com = new System.Windows.Forms.ComboBox();
             this.label5 = new System.Windows.Forms.Label();
             this.panel1.SuspendLayout();
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
             this.panel2.SuspendLayout();
             this.panel_wrapper.SuspendLayout();
             this.panel3.SuspendLayout();
             this.statusStrip1.SuspendLayout();
             this.tabControl1.SuspendLayout();
             this.tb_hiredoc.SuspendLayout();
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
             this.panel4.SuspendLayout();
             this.panel5.SuspendLayout();
             this.panel9.SuspendLayout();
             this.panel8.SuspendLayout();
             this.panel7.SuspendLayout();
             this.panel6.SuspendLayout();
             this.tab_viewdoc.SuspendLayout();
             ((System.ComponentModel.ISupportInitialize)(this.dgv_doc)).BeginInit();
             this.tab_mandoc.SuspendLayout();
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
             this.panel10.SuspendLayout();
             this.panel11.SuspendLayout();
             this.panel12.SuspendLayout();
             this.panel13.SuspendLayout();
             this.panel14.SuspendLayout();
             this.panel15.SuspendLayout();
             this.SuspendLayout();
             // 
             // panel1
             // 
             this.panel1.BackColor = System.Drawing.Color.Firebrick;
             this.panel1.Controls.Add(this.btn_close_window);
             this.panel1.Controls.Add(this.pictureBox1);
             this.panel1.Controls.Add(this.lbl_head);
             this.panel1.ForeColor = System.Drawing.SystemColors.Info;
             this.panel1.Location = new System.Drawing.Point(0, 0);
             this.panel1.Name = "panel1";
             this.panel1.Size = new System.Drawing.Size(656, 35);
             this.panel1.TabIndex = 4;
             // 
             // btn_close_window
             // 
             this.btn_close_window.DialogResult = System.Windows.Forms.DialogResult.Cancel;
             this.btn_close_window.FlatAppearance.BorderSize = 0;
             this.btn_close_window.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
             this.btn_close_window.ForeColor = System.Drawing.SystemColors.Info;
             this.btn_close_window.Location = new System.Drawing.Point(620, 0);
             this.btn_close_window.Name = "btn_close_window";
             this.btn_close_window.Size = new System.Drawing.Size(36, 35);
             this.btn_close_window.TabIndex = 6;
             this.btn_close_window.Text = "X";
             this.btn_close_window.UseVisualStyleBackColor = true;
             this.btn_close_window.Click += new System.EventHandler(this.btn_close_window_Click);
             // 
             // pictureBox1
             // 
             this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
             this.pictureBox1.Location = new System.Drawing.Point(3, 4);
             this.pictureBox1.Name = "pictureBox1";
             this.pictureBox1.Size = new System.Drawing.Size(30, 30);
             this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
             this.pictureBox1.TabIndex = 3;
             this.pictureBox1.TabStop = false;
             // 
             // lbl_head
             // 
             this.lbl_head.AutoSize = true;
             this.lbl_head.Location = new System.Drawing.Point(31, 11);
             this.lbl_head.Name = "lbl_head";
             this.lbl_head.Size = new System.Drawing.Size(44, 13);
             this.lbl_head.TabIndex = 2;
             this.lbl_head.Text = "Doctors";
             // 
             // panel2
             // 
             this.panel2.BackColor = System.Drawing.SystemColors.HighlightText;
             this.panel2.Controls.Add(this.panel_wrapper);
             this.panel2.Location = new System.Drawing.Point(0, 35);
             this.panel2.Name = "panel2";
             this.panel2.Size = new System.Drawing.Size(656, 465);
             this.panel2.TabIndex = 5;
             // 
             // panel_wrapper
             // 
             this.panel_wrapper.Controls.Add(this.panel3);
             this.panel_wrapper.Controls.Add(this.tabControl1);
             this.panel_wrapper.Location = new System.Drawing.Point(12, 13);
             this.panel_wrapper.Name = "panel_wrapper";
             this.panel_wrapper.Size = new System.Drawing.Size(629, 430);
             this.panel_wrapper.TabIndex = 2;
             // 
             // panel3
             // 
             this.panel3.Controls.Add(this.statusStrip1);
             this.panel3.Location = new System.Drawing.Point(18, 400);
             this.panel3.Name = "panel3";
             this.panel3.Size = new System.Drawing.Size(592, 25);
             this.panel3.TabIndex = 7;
             // 
             // statusStrip1
             // 
             this.statusStrip1.Dock = System.Windows.Forms.DockStyle.Top;
             this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lbl_status});
             this.statusStrip1.Location = new System.Drawing.Point(0, 0);
             this.statusStrip1.Name = "statusStrip1";
             this.statusStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
             this.statusStrip1.Size = new System.Drawing.Size(592, 22);
             this.statusStrip1.TabIndex = 7;
             this.statusStrip1.Text = "statusStrip1";
             // 
             // lbl_status
             // 
             this.lbl_status.Name = "lbl_status";
             this.lbl_status.Size = new System.Drawing.Size(39, 17);
             this.lbl_status.Text = "Ready";
             // 
             // tabControl1
             // 
             this.tabControl1.Controls.Add(this.tb_hiredoc);
             this.tabControl1.Controls.Add(this.tab_viewdoc);
             this.tabControl1.Controls.Add(this.tab_mandoc);
             this.tabControl1.Location = new System.Drawing.Point(18, 13);
             this.tabControl1.Name = "tabControl1";
             this.tabControl1.SelectedIndex = 0;
             this.tabControl1.Size = new System.Drawing.Size(596, 385);
             this.tabControl1.TabIndex = 0;
             this.tabControl1.SelectedIndexChanged += new System.EventHandler(this.tabControl1_SelectedIndexChanged);
             // 
             // tb_hiredoc
             // 
             this.tb_hiredoc.Controls.Add(this.pictureBox2);
             this.tb_hiredoc.Controls.Add(this.btn_insert);
             this.tb_hiredoc.Controls.Add(this.panel4);
             this.tb_hiredoc.Location = new System.Drawing.Point(4, 22);
             this.tb_hiredoc.Name = "tb_hiredoc";
             this.tb_hiredoc.Padding = new System.Windows.Forms.Padding(3);
             this.tb_hiredoc.Size = new System.Drawing.Size(588, 359);
             this.tb_hiredoc.TabIndex = 1;
             this.tb_hiredoc.Text = "Hire Doctor";
             this.tb_hiredoc.UseVisualStyleBackColor = true;
             // 
             // pictureBox2
             // 
             this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
             this.pictureBox2.Location = new System.Drawing.Point(411, 7);
             this.pictureBox2.Name = "pictureBox2";
             this.pictureBox2.Size = new System.Drawing.Size(171, 186);
             this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
             this.pictureBox2.TabIndex = 3;
             this.pictureBox2.TabStop = false;
             // 
             // btn_insert
             // 
             this.btn_insert.BackColor = System.Drawing.Color.Chocolate;
             this.btn_insert.ForeColor = System.Drawing.SystemColors.Info;
             this.btn_insert.Location = new System.Drawing.Point(317, 214);
             this.btn_insert.Name = "btn_insert";
             this.btn_insert.Size = new System.Drawing.Size(75, 23);
             this.btn_insert.TabIndex = 8;
             this.btn_insert.Text = "Insert";
             this.btn_insert.UseVisualStyleBackColor = false;
             this.btn_insert.Click += new System.EventHandler(this.btn_insert_Click);
             // 
             // panel4
             // 
             this.panel4.Controls.Add(this.panel5);
             this.panel4.Controls.Add(this.panel9);
             this.panel4.Controls.Add(this.panel8);
             this.panel4.Controls.Add(this.panel7);
             this.panel4.Controls.Add(this.panel6);
             this.panel4.Location = new System.Drawing.Point(7, 7);
             this.panel4.Name = "panel4";
             this.panel4.Size = new System.Drawing.Size(400, 186);
             this.panel4.TabIndex = 0;
             // 
             // panel5
             // 
             this.panel5.BackColor = System.Drawing.Color.FloralWhite;
             this.panel5.Controls.Add(this.btn_new_dept);
             this.panel5.Controls.Add(this.lbl_dep);
             this.panel5.Controls.Add(this.lb_department);
             this.panel5.Location = new System.Drawing.Point(262, 56);
             this.panel5.Name = "panel5";
             this.panel5.Size = new System.Drawing.Size(135, 127);
             this.panel5.TabIndex = 4;
             // 
             // btn_new_dept
             // 
             this.btn_new_dept.BackColor = System.Drawing.Color.Chocolate;
             this.btn_new_dept.ForeColor = System.Drawing.SystemColors.Info;
             this.btn_new_dept.Location = new System.Drawing.Point(77, 3);
             this.btn_new_dept.Name = "btn_new_dept";
             this.btn_new_dept.Size = new System.Drawing.Size(46, 21);
             this.btn_new_dept.TabIndex = 6;
             this.btn_new_dept.Text = "New";
             this.btn_new_dept.UseVisualStyleBackColor = false;
             this.btn_new_dept.Click += new System.EventHandler(this.btn_new_Click);
             // 
             // lbl_dep
             // 
             this.lbl_dep.AutoSize = true;
             this.lbl_dep.Location = new System.Drawing.Point(9, 7);
             this.lbl_dep.Name = "lbl_dep";
             this.lbl_dep.Size = new System.Drawing.Size(62, 13);
             this.lbl_dep.TabIndex = 3;
             this.lbl_dep.Text = "Department";
             // 
             // lb_department
             // 
             this.lb_department.FormattingEnabled = true;
             this.lb_department.Location = new System.Drawing.Point(12, 28);
             this.lb_department.Name = "lb_department";
             this.lb_department.Size = new System.Drawing.Size(111, 95);
             this.lb_department.TabIndex = 7;
             // 
             // panel9
             // 
             this.panel9.BackColor = System.Drawing.Color.FloralWhite;
             this.panel9.Controls.Add(this.txt_add);
             this.panel9.Controls.Add(this.lbl_address);
             this.panel9.Location = new System.Drawing.Point(0, 126);
             this.panel9.Name = "panel9";
             this.panel9.Size = new System.Drawing.Size(256, 57);
             this.panel9.TabIndex = 2;
             // 
             // txt_add
             // 
             this.txt_add.Location = new System.Drawing.Point(73, 18);
             this.txt_add.Name = "txt_add";
             this.txt_add.Size = new System.Drawing.Size(169, 20);
             this.txt_add.TabIndex = 3;
             // 
             // lbl_address
             // 
             this.lbl_address.AutoSize = true;
             this.lbl_address.Location = new System.Drawing.Point(18, 21);
             this.lbl_address.Name = "lbl_address";
             this.lbl_address.Size = new System.Drawing.Size(45, 13);
             this.lbl_address.TabIndex = 6;
             this.lbl_address.Text = "Address";
             // 
             // panel8
             // 
             this.panel8.BackColor = System.Drawing.Color.FloralWhite;
             this.panel8.Controls.Add(this.txt_con);
             this.panel8.Controls.Add(this.lbl_contact);
             this.panel8.Location = new System.Drawing.Point(0, 63);
             this.panel8.Name = "panel8";
             this.panel8.Size = new System.Drawing.Size(256, 57);
             this.panel8.TabIndex = 1;
             // 
             // txt_con
             // 
             this.txt_con.Location = new System.Drawing.Point(73, 18);
             this.txt_con.Name = "txt_con";
             this.txt_con.Size = new System.Drawing.Size(169, 20);
             this.txt_con.TabIndex = 2;
             // 
             // lbl_contact
             // 
             this.lbl_contact.AutoSize = true;
             this.lbl_contact.Location = new System.Drawing.Point(3, 21);
             this.lbl_contact.Name = "lbl_contact";
             this.lbl_contact.Size = new System.Drawing.Size(64, 13);
             this.lbl_contact.TabIndex = 4;
             this.lbl_contact.Text = "Contact No.";
             // 
             // panel7
             // 
             this.panel7.BackColor = System.Drawing.Color.FloralWhite;
             this.panel7.Controls.Add(this.lbl_gender);
             this.panel7.Controls.Add(this.rad_female);
             this.panel7.Controls.Add(this.rad_male);
             this.panel7.Location = new System.Drawing.Point(262, 0);
             this.panel7.Name = "panel7";
             this.panel7.Size = new System.Drawing.Size(135, 48);
             this.panel7.TabIndex = 3;
             // 
             // lbl_gender
             // 
             this.lbl_gender.AutoSize = true;
             this.lbl_gender.Location = new System.Drawing.Point(42, 6);
             this.lbl_gender.Name = "lbl_gender";
             this.lbl_gender.Size = new System.Drawing.Size(42, 13);
             this.lbl_gender.TabIndex = 2;
             this.lbl_gender.Text = "Gender";
             // 
             // rad_female
             // 
             this.rad_female.AutoSize = true;
             this.rad_female.Location = new System.Drawing.Point(64, 24);
             this.rad_female.Name = "rad_female";
             this.rad_female.Size = new System.Drawing.Size(59, 17);
             this.rad_female.TabIndex = 5;
             this.rad_female.Text = "Female";
             this.rad_female.UseVisualStyleBackColor = true;
             // 
             // rad_male
             // 
             this.rad_male.AutoSize = true;
             this.rad_male.Checked = true;
             this.rad_male.Location = new System.Drawing.Point(12, 24);
             this.rad_male.Name = "rad_male";
             this.rad_male.Size = new System.Drawing.Size(48, 17);
             this.rad_male.TabIndex = 4;
             this.rad_male.TabStop = true;
             this.rad_male.Text = "Male";
             this.rad_male.UseVisualStyleBackColor = true;
             // 
             // panel6
             // 
             this.panel6.BackColor = System.Drawing.Color.FloralWhite;
             this.panel6.Controls.Add(this.lbl_name);
             this.panel6.Controls.Add(this.txt_name);
             this.panel6.Location = new System.Drawing.Point(0, 0);
             this.panel6.Name = "panel6";
             this.panel6.Size = new System.Drawing.Size(256, 57);
             this.panel6.TabIndex = 0;
             // 
             // lbl_name
             // 
             this.lbl_name.AutoSize = true;
             this.lbl_name.Location = new System.Drawing.Point(18, 21);
             this.lbl_name.Name = "lbl_name";
             this.lbl_name.Size = new System.Drawing.Size(35, 13);
             this.lbl_name.TabIndex = 2;
             this.lbl_name.Text = "Name";
             // 
             // txt_name
             // 
             this.txt_name.Location = new System.Drawing.Point(73, 18);
             this.txt_name.Name = "txt_name";
             this.txt_name.Size = new System.Drawing.Size(169, 20);
             this.txt_name.TabIndex = 1;
             this.txt_name.Text = "Dr.";
             // 
             // tab_viewdoc
             // 
             this.tab_viewdoc.Controls.Add(this.dgv_doc);
             this.tab_viewdoc.Controls.Add(this.txt_search);
             this.tab_viewdoc.Controls.Add(this.com_search);
             this.tab_viewdoc.Controls.Add(this.lbl_search);
             this.tab_viewdoc.Location = new System.Drawing.Point(4, 22);
             this.tab_viewdoc.Name = "tab_viewdoc";
             this.tab_viewdoc.Padding = new System.Windows.Forms.Padding(3);
             this.tab_viewdoc.Size = new System.Drawing.Size(588, 359);
             this.tab_viewdoc.TabIndex = 0;
             this.tab_viewdoc.Text = "View Doctors";
             this.tab_viewdoc.UseVisualStyleBackColor = true;
             // 
             // dgv_doc
             // 
             this.dgv_doc.AllowUserToAddRows = false;
             this.dgv_doc.AllowUserToDeleteRows = false;
             this.dgv_doc.AllowUserToOrderColumns = true;
             this.dgv_doc.AllowUserToResizeColumns = false;
             this.dgv_doc.AllowUserToResizeRows = false;
             dataGridViewCellStyle1.BackColor = System.Drawing.Color.WhiteSmoke;
             dataGridViewCellStyle1.ForeColor = System.Drawing.Color.Black;
             dataGridViewCellStyle1.Padding = new System.Windows.Forms.Padding(2);
             dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightGray;
             dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.Black;
             this.dgv_doc.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
             this.dgv_doc.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
             this.dgv_doc.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken;
             this.dgv_doc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
             dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
             dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
             dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
             dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
             dataGridViewCellStyle2.Padding = new System.Windows.Forms.Padding(2);
             dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightGray;
             dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.Black;
             dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
             this.dgv_doc.DefaultCellStyle = dataGridViewCellStyle2;
             this.dgv_doc.GridColor = System.Drawing.SystemColors.ActiveCaption;
             this.dgv_doc.Location = new System.Drawing.Point(3, 3);
             this.dgv_doc.Name = "dgv_doc";
             this.dgv_doc.Size = new System.Drawing.Size(582, 194);
             this.dgv_doc.TabIndex = 7;
             // 
             // txt_search
             // 
             this.txt_search.Location = new System.Drawing.Point(90, 242);
             this.txt_search.Name = "txt_search";
             this.txt_search.Size = new System.Drawing.Size(180, 20);
             this.txt_search.TabIndex = 4;
             this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
             // 
             // com_search
             // 
             this.com_search.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
             this.com_search.FormattingEnabled = true;
             this.com_search.Items.AddRange(new object[] {
            "Name",
            "Department"});
             this.com_search.Location = new System.Drawing.Point(90, 214);
             this.com_search.Name = "com_search";
             this.com_search.Size = new System.Drawing.Size(180, 21);
             this.com_search.TabIndex = 2;
             // 
             // lbl_search
             // 
             this.lbl_search.AutoSize = true;
             this.lbl_search.Location = new System.Drawing.Point(14, 217);
             this.lbl_search.Name = "lbl_search";
             this.lbl_search.Size = new System.Drawing.Size(56, 13);
             this.lbl_search.TabIndex = 1;
             this.lbl_search.Text = "Search By";
             // 
             // tab_mandoc
             // 
             this.tab_mandoc.Controls.Add(this.pictureBox3);
             this.tab_mandoc.Controls.Add(this.btn_update);
             this.tab_mandoc.Controls.Add(this.panel10);
             this.tab_mandoc.Location = new System.Drawing.Point(4, 22);
             this.tab_mandoc.Name = "tab_mandoc";
             this.tab_mandoc.Padding = new System.Windows.Forms.Padding(3);
             this.tab_mandoc.Size = new System.Drawing.Size(588, 359);
             this.tab_mandoc.TabIndex = 2;
             this.tab_mandoc.Text = "Manage Doctors";
             this.tab_mandoc.UseVisualStyleBackColor = true;
             // 
             // pictureBox3
             // 
             this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
             this.pictureBox3.Location = new System.Drawing.Point(410, 3);
             this.pictureBox3.Name = "pictureBox3";
             this.pictureBox3.Size = new System.Drawing.Size(171, 186);
             this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
             this.pictureBox3.TabIndex = 6;
             this.pictureBox3.TabStop = false;
             // 
             // btn_update
             // 
             this.btn_update.BackColor = System.Drawing.Color.Chocolate;
             this.btn_update.ForeColor = System.Drawing.SystemColors.Info;
             this.btn_update.Location = new System.Drawing.Point(319, 210);
             this.btn_update.Name = "btn_update";
             this.btn_update.Size = new System.Drawing.Size(75, 23);
             this.btn_update.TabIndex = 5;
             this.btn_update.Text = "Update";
             this.btn_update.UseVisualStyleBackColor = false;
             this.btn_update.Click += new System.EventHandler(this.btn_update_Click);
             // 
             // panel10
             // 
             this.panel10.Controls.Add(this.panel11);
             this.panel10.Controls.Add(this.panel12);
             this.panel10.Controls.Add(this.panel13);
             this.panel10.Controls.Add(this.panel14);
             this.panel10.Controls.Add(this.panel15);
             this.panel10.Location = new System.Drawing.Point(6, 3);
             this.panel10.Name = "panel10";
             this.panel10.Size = new System.Drawing.Size(400, 186);
             this.panel10.TabIndex = 4;
             // 
             // panel11
             // 
             this.panel11.BackColor = System.Drawing.Color.FloralWhite;
             this.panel11.Controls.Add(this.com_dep);
             this.panel11.Controls.Add(this.label1);
             this.panel11.Location = new System.Drawing.Point(262, 63);
             this.panel11.Name = "panel11";
             this.panel11.Size = new System.Drawing.Size(135, 57);
             this.panel11.TabIndex = 3;
             // 
             // com_dep
             // 
             this.com_dep.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
             this.com_dep.FormattingEnabled = true;
             this.com_dep.Location = new System.Drawing.Point(12, 21);
             this.com_dep.Name = "com_dep";
             this.com_dep.Size = new System.Drawing.Size(111, 21);
             this.com_dep.TabIndex = 4;
             this.com_dep.SelectedIndexChanged += new System.EventHandler(this.com_dep_SelectedIndexChanged);
             // 
             // label1
             // 
             this.label1.AutoSize = true;
             this.label1.Location = new System.Drawing.Point(9, 7);
             this.label1.Name = "label1";
             this.label1.Size = new System.Drawing.Size(62, 13);
             this.label1.TabIndex = 3;
             this.label1.Text = "Department";
             // 
             // panel12
             // 
             this.panel12.BackColor = System.Drawing.Color.FloralWhite;
             this.panel12.Controls.Add(this.txt_add2);
             this.panel12.Controls.Add(this.label2);
             this.panel12.Location = new System.Drawing.Point(3, 126);
             this.panel12.Name = "panel12";
             this.panel12.Size = new System.Drawing.Size(394, 57);
             this.panel12.TabIndex = 4;
             // 
             // txt_add2
             // 
             this.txt_add2.Location = new System.Drawing.Point(73, 18);
             this.txt_add2.Name = "txt_add2";
             this.txt_add2.Size = new System.Drawing.Size(312, 20);
             this.txt_add2.TabIndex = 7;
             // 
             // label2
             // 
             this.label2.AutoSize = true;
             this.label2.Location = new System.Drawing.Point(18, 21);
             this.label2.Name = "label2";
             this.label2.Size = new System.Drawing.Size(45, 13);
             this.label2.TabIndex = 6;
             this.label2.Text = "Address";
             // 
             // panel13
             // 
             this.panel13.BackColor = System.Drawing.Color.FloralWhite;
             this.panel13.Controls.Add(this.txt_con2);
             this.panel13.Controls.Add(this.label3);
             this.panel13.Location = new System.Drawing.Point(3, 63);
             this.panel13.Name = "panel13";
             this.panel13.Size = new System.Drawing.Size(253, 57);
             this.panel13.TabIndex = 2;
             // 
             // txt_con2
             // 
             this.txt_con2.Location = new System.Drawing.Point(73, 18);
             this.txt_con2.Name = "txt_con2";
             this.txt_con2.Size = new System.Drawing.Size(169, 20);
             this.txt_con2.TabIndex = 5;
             // 
             // label3
             // 
             this.label3.AutoSize = true;
             this.label3.Location = new System.Drawing.Point(3, 21);
             this.label3.Name = "label3";
             this.label3.Size = new System.Drawing.Size(64, 13);
             this.label3.TabIndex = 4;
             this.label3.Text = "Contact No.";
             // 
             // panel14
             // 
             this.panel14.BackColor = System.Drawing.Color.FloralWhite;
             this.panel14.Controls.Add(this.label4);
             this.panel14.Controls.Add(this.rad_female2);
             this.panel14.Controls.Add(this.rad_male2);
             this.panel14.Location = new System.Drawing.Point(262, 0);
             this.panel14.Name = "panel14";
             this.panel14.Size = new System.Drawing.Size(135, 57);
             this.panel14.TabIndex = 1;
             // 
             // label4
             // 
             this.label4.AutoSize = true;
             this.label4.Location = new System.Drawing.Point(42, 6);
             this.label4.Name = "label4";
             this.label4.Size = new System.Drawing.Size(42, 13);
             this.label4.TabIndex = 2;
             this.label4.Text = "Gender";
             // 
             // rad_female2
             // 
             this.rad_female2.AutoSize = true;
             this.rad_female2.Location = new System.Drawing.Point(64, 24);
             this.rad_female2.Name = "rad_female2";
             this.rad_female2.Size = new System.Drawing.Size(59, 17);
             this.rad_female2.TabIndex = 1;
             this.rad_female2.Text = "Female";
             this.rad_female2.UseVisualStyleBackColor = true;
             // 
             // rad_male2
             // 
             this.rad_male2.AutoSize = true;
             this.rad_male2.Checked = true;
             this.rad_male2.Location = new System.Drawing.Point(12, 24);
             this.rad_male2.Name = "rad_male2";
             this.rad_male2.Size = new System.Drawing.Size(48, 17);
             this.rad_male2.TabIndex = 0;
             this.rad_male2.TabStop = true;
             this.rad_male2.Text = "Male";
             this.rad_male2.UseVisualStyleBackColor = true;
             // 
             // panel15
             // 
             this.panel15.BackColor = System.Drawing.Color.FloralWhite;
             this.panel15.Controls.Add(this.txt_name_com);
             this.panel15.Controls.Add(this.label5);
             this.panel15.Location = new System.Drawing.Point(3, 0);
             this.panel15.Name = "panel15";
             this.panel15.Size = new System.Drawing.Size(253, 57);
             this.panel15.TabIndex = 0;
             // 
             // txt_name_com
             // 
             this.txt_name_com.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
             this.txt_name_com.FormattingEnabled = true;
             this.txt_name_com.Location = new System.Drawing.Point(73, 21);
             this.txt_name_com.Name = "txt_name_com";
             this.txt_name_com.Size = new System.Drawing.Size(169, 21);
             this.txt_name_com.TabIndex = 3;
             this.txt_name_com.SelectedIndexChanged += new System.EventHandler(this.txt_name_com_SelectedIndexChanged);
             // 
             // label5
             // 
             this.label5.AutoSize = true;
             this.label5.Location = new System.Drawing.Point(18, 21);
             this.label5.Name = "label5";
             this.label5.Size = new System.Drawing.Size(35, 13);
             this.label5.TabIndex = 2;
             this.label5.Text = "Name";
             // 
             // doctors
             // 
             this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
             this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
             this.ClientSize = new System.Drawing.Size(658, 500);
             this.Controls.Add(this.panel2);
             this.Controls.Add(this.panel1);
             this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
             this.Name = "doctors";
             this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
             this.Text = "doctor";
             this.Load += new System.EventHandler(this.doctor_Load);
             this.panel1.ResumeLayout(false);
             this.panel1.PerformLayout();
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
             this.panel2.ResumeLayout(false);
             this.panel_wrapper.ResumeLayout(false);
             this.panel3.ResumeLayout(false);
             this.panel3.PerformLayout();
             this.statusStrip1.ResumeLayout(false);
             this.statusStrip1.PerformLayout();
             this.tabControl1.ResumeLayout(false);
             this.tb_hiredoc.ResumeLayout(false);
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
             this.panel4.ResumeLayout(false);
             this.panel5.ResumeLayout(false);
             this.panel5.PerformLayout();
             this.panel9.ResumeLayout(false);
             this.panel9.PerformLayout();
             this.panel8.ResumeLayout(false);
             this.panel8.PerformLayout();
             this.panel7.ResumeLayout(false);
             this.panel7.PerformLayout();
             this.panel6.ResumeLayout(false);
             this.panel6.PerformLayout();
             this.tab_viewdoc.ResumeLayout(false);
             this.tab_viewdoc.PerformLayout();
             ((System.ComponentModel.ISupportInitialize)(this.dgv_doc)).EndInit();
             this.tab_mandoc.ResumeLayout(false);
             ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
             this.panel10.ResumeLayout(false);
             this.panel11.ResumeLayout(false);
             this.panel11.PerformLayout();
             this.panel12.ResumeLayout(false);
             this.panel12.PerformLayout();
             this.panel13.ResumeLayout(false);
             this.panel13.PerformLayout();
             this.panel14.ResumeLayout(false);
             this.panel14.PerformLayout();
             this.panel15.ResumeLayout(false);
             this.panel15.PerformLayout();
             this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_head;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel_wrapper;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tab_viewdoc;
        private System.Windows.Forms.TabPage tb_hiredoc;
        private System.Windows.Forms.ComboBox com_search;
        private System.Windows.Forms.Label lbl_search;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txt_add;
        private System.Windows.Forms.Label lbl_address;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.TextBox txt_con;
        private System.Windows.Forms.Label lbl_contact;
        private System.Windows.Forms.ListBox lb_department;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.TextBox txt_name;
        private System.Windows.Forms.Label lbl_name;
        private System.Windows.Forms.Button btn_insert;
        private System.Windows.Forms.Label lbl_gender;
        private System.Windows.Forms.RadioButton rad_female;
        private System.Windows.Forms.RadioButton rad_male;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btn_new_dept;
        private System.Windows.Forms.Label lbl_dep;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel lbl_status;
        private System.Windows.Forms.Button btn_close_window;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.DataGridView dgv_doc;
        private System.Windows.Forms.TabPage tab_mandoc;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button btn_update;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txt_add2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.TextBox txt_con2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.RadioButton rad_female2;
        private System.Windows.Forms.RadioButton rad_male2;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox txt_name_com;
        private System.Windows.Forms.ComboBox com_dep;
    }
}