﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMS
{
    public partial class department : Form
    {
        SqlConnection scon = new SqlConnection(connection.connmethod());
        SqlCommand scom;
        //SqlDataReader sdr;
        string sql;

        public department()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            bool ins = false;
            int c;

            scon.Open();
            sql = "SELECT count(*) from Departments WHERE name ='" + txt_dep.Text + "'";
            SqlCommand scom2 = new SqlCommand(sql, scon);
            c = (int) scom2.ExecuteScalar();
            try
            {
                if (txt_dep.Text != "")
                {
                    if(!(c>0) )
                    {
                        dept obj = new dept();
                        scom = new SqlCommand(obj.dept_check(txt_dep.Text), scon);
                        scom.ExecuteNonQuery();
                        ins = true;
                    }
                    else
                    {
                        ins = false;
                        MessageBox.Show("Department already exists !");
                    }
                }
                else
                {
                    MessageBox.Show("Department name required!");
                }
            }
            catch (Exception ex)
            {
                ins = false;
                MessageBox.Show(ex.Message);
            }
            finally
            {
                scon.Close();
                doctors doc = new doctors();
                doc.listbox_departments();    

            }

            if (ins)
            {
                this.Close();
            }
        }

        private void btn_close_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void department_FormClosed(object sender, FormClosedEventArgs e)
        {

        }

        private void btn_close_window_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
