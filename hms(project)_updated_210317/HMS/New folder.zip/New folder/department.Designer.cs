﻿namespace HMS
{
    partial class department
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl_add_dep = new System.Windows.Forms.Label();
            this.txt_dep = new System.Windows.Forms.TextBox();
            this.btn_add = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_close_window = new System.Windows.Forms.Button();
            this.lbl_head = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lbl_add_dep
            // 
            this.lbl_add_dep.AutoSize = true;
            this.lbl_add_dep.Location = new System.Drawing.Point(24, 35);
            this.lbl_add_dep.Name = "lbl_add_dep";
            this.lbl_add_dep.Size = new System.Drawing.Size(84, 13);
            this.lbl_add_dep.TabIndex = 0;
            this.lbl_add_dep.Text = "Add Department";
            this.lbl_add_dep.Click += new System.EventHandler(this.label1_Click);
            // 
            // txt_dep
            // 
            this.txt_dep.Location = new System.Drawing.Point(27, 52);
            this.txt_dep.Name = "txt_dep";
            this.txt_dep.Size = new System.Drawing.Size(195, 20);
            this.txt_dep.TabIndex = 1;
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.Chocolate;
            this.btn_add.ForeColor = System.Drawing.SystemColors.Info;
            this.btn_add.Location = new System.Drawing.Point(147, 78);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(75, 23);
            this.btn_add.TabIndex = 2;
            this.btn_add.Text = "Add";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Firebrick;
            this.panel1.Controls.Add(this.btn_close_window);
            this.panel1.Controls.Add(this.lbl_head);
            this.panel1.ForeColor = System.Drawing.SystemColors.Info;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(252, 21);
            this.panel1.TabIndex = 7;
            // 
            // btn_close_window
            // 
            this.btn_close_window.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.btn_close_window.FlatAppearance.BorderSize = 0;
            this.btn_close_window.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close_window.ForeColor = System.Drawing.SystemColors.Info;
            this.btn_close_window.Location = new System.Drawing.Point(228, 0);
            this.btn_close_window.Name = "btn_close_window";
            this.btn_close_window.Size = new System.Drawing.Size(24, 22);
            this.btn_close_window.TabIndex = 6;
            this.btn_close_window.Text = "X";
            this.btn_close_window.UseVisualStyleBackColor = true;
            this.btn_close_window.Click += new System.EventHandler(this.btn_close_window_Click);
            // 
            // lbl_head
            // 
            this.lbl_head.AutoSize = true;
            this.lbl_head.Location = new System.Drawing.Point(3, 4);
            this.lbl_head.Name = "lbl_head";
            this.lbl_head.Size = new System.Drawing.Size(62, 13);
            this.lbl_head.TabIndex = 2;
            this.lbl_head.Text = "Department";
            // 
            // department
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FloralWhite;
            this.ClientSize = new System.Drawing.Size(251, 123);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btn_add);
            this.Controls.Add(this.txt_dep);
            this.Controls.Add(this.lbl_add_dep);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "department";
            this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
            this.Text = "department";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.department_FormClosed);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_add_dep;
        private System.Windows.Forms.TextBox txt_dep;
        private System.Windows.Forms.Button btn_add;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btn_close_window;
        private System.Windows.Forms.Label lbl_head;
    }
}