﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;

namespace HMS
{
    class dept
    {
        string sql;

        SqlConnection scon = new SqlConnection(connection.connmethod());

        public string dept_check(string a)
        {
            sql = "IF(NOT EXISTS(SELECT * from Departments WHERE name ='"+ a +"')) BEGIN INSERT INTO Departments(name) VALUES ('"+a+"') END";
            return sql;
        }
    }
}
