﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HMS
{
    class login_access
    {
        public string sql { get; set; }
        public string pass { get; set; }
        public string user { get; set; }
        public int c { get; set; }
    }
}
