﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HMS
{
    class doc:operation
    {
        public string sql{ get; set; }
        public string gender{ get; set; }
        public string depart_id { get; set;}
        public string doct_id{ get; set; }
    }   
}
