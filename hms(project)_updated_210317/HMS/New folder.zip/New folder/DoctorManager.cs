﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Windows.Forms;

namespace HMS
{
     class DoctorManager
     {
          SqlConnection scon = new SqlConnection(connection.connmethod());

          doc docs = new doc();
          operation op = new operation();

          public DataSet show_doctors()
          {
               docs.sql = "SELECT d.id,d.name[Doctor Name],dep.name[Department],d.gender[Gender],d.address[Address],d.contact[Contact No.] from Doctors d JOIN Departments dep ON d.department_id = dep.id";
               return op.show(docs.sql);
          }

          public DataSet select_dept()
          {
               docs.sql = "SELECT * FROM departments";
               return op.show(docs.sql);
          }

          public DataSet show_doc_combo()
          {
               docs.sql = "Select id,name from Doctors";
               return op.show(docs.sql);
          }

          public DataSet show_dept_combo()
          {
               docs.sql = "Select id,name from Departments";
               return op.show(docs.sql);
          }

          public string insert_doc(string dep)
          {
               docs.sql = "SELECT id from Departments where name = '" + dep + "';";
               return op.get_id(docs.sql);
          }

          //public void search_doc(datagridview dgv, textbox search, combobox com_search)
          //{
          //     string q, q1, q2, q3;
          //     q = "select d.name[doctor name],dep.name[department],d.gender[gender],d.address[address],d.contact[contact no.] from doctors d join departments dep on d.department_id = dep.id";
          //     q1 = q + " where d.name like '%" + search.text + "%'";
          //     q2 = q + " where dep.name like '%" + search.text + "%'";
          //     q3 = q + " where d.name like '%" + search.text + "%'";
          //     txt_search(dgv, search, com_search, q, q1, q2, q3);
          //}

          public DataSet show_doc_details(string doctor)
          {
               docs.sql = "Select dep.name,d.gender,d.address,d.contact from Doctors d JOIN Departments dep ON d.department_id = dep.id WHERE d.name= '" + doctor + "'";
               return op.show(docs.sql);               
          }

          public string update_doc(string doc)
          {
               docs.sql = "SELECT id from Doctors where name = '" + doc + "';";
               return op.get_id(docs.sql);
          }

          public void delete_doc(string doc)
          {
               docs.sql = "SELECT id from Doctors where name = '" + doc + "';";
               string doc_id = op.get_id(docs.sql);

               docs.sql = "DELETE FROM Doctors WHERE id ='" + doc_id + "'";
               op.insert(docs.sql);
          }

     }
}
